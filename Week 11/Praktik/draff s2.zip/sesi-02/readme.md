Nama    : Claudia V.T. Panjaitan
NIM     : 41426004
Prodi   : D IV TRPL

LAPORAN PRAKTIKUM PENGEMBANGAN SITUS WEB 1 WEEK 11 SESI 2





AI USE STATEMENT
Dalam praktikum ini, saya menggunakan AI untuk membantu memahami fungsi kode HTML dan JavaScript serta menjelaskan cara kerja program dengan bahasa yang lebih sederhana dan menyusun kalimat dalam membuat penjelasan. AI juga membantu memberikan gambaran mengenai kemungkinan kesalahan pada kode. Hasil dari AI saya pelajari kembali dan saya periksa dengan menjalankan program secara langsung melalui browser. AI digunakan sebagai alat bantu belajar untuk menambah pemahaman, bukan untuk menggantikan proses belajar saya sendiri.